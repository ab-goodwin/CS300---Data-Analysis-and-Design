//============================================================================
// Name        : Project 2.cpp
// Author      : Brady Goodwin
// Version     : 1.0
// Description : Project 2 - ABCU Advising Assistance Program
//============================================================================ 

#include <vector>
#include <iostream>
#include <iomanip>
#include <fstream>
#include <sstream>
#include <cstring>
#include <ctime>

using namespace std;

// DEFINE COURSE STRUCT
struct Course {
    string courseId;
    string title;
    vector<string> prereq;

    Course() : courseId(""), title(""), prereq({}) {}
};

// BST NODE DEFINITION
struct Node {
    Course course;
    Node* left = nullptr;
    Node* right = nullptr;

    Node(Course aCourse) : course(aCourse) {}
};

// BST DEFINITION
class BinarySearchTree {
private:
    Node* root;
    void addNode(Node*& node, Course course);
    void inOrder(Node* node);

public:
    BinarySearchTree() : root(nullptr), size(0) {}
    ~BinarySearchTree() { DestroyBST(root); }

    void InOrder() { inOrder(root); }
    void Insert(Course course) { addNode(root, course); ++size; }
    Course Search(const string& courseId);
    void DestroyBST(Node* node);
    int size;
};

// RECURSIVE BST NODE INSERTION
void BinarySearchTree::addNode(Node*& node, Course course) {
    if (node == nullptr) {
        node = new Node(course);
    }
    else if (course.courseId < node->course.courseId) {
        addNode(node->left, course);
    }
    else {
        addNode(node->right, course);
    }
}

// RECURSIVE INORDER TRAVERSAL
void BinarySearchTree::inOrder(Node* node) {
    if (node != nullptr) {
        inOrder(node->left);
        cout << node->course.courseId << ": " << node->course.title << " | ";
        if (node->course.prereq.empty()) {
            cout << "No prerequisites" << endl;
        }
        else {
            cout << "Prerequisites: ";
            for (const auto& prereq : node->course.prereq) {
                cout << prereq << " ";
            }
            cout << endl;
        }
        inOrder(node->right);
    }
}

// RECURSIVE BST DESTRUCTION
void BinarySearchTree::DestroyBST(Node* node) {
    if (node != nullptr) {
        DestroyBST(node->left);
        DestroyBST(node->right);
        delete node;
    }
}

// SEARCH BY COURSEID
Course BinarySearchTree::Search(const string& courseId) {
    Node* curr = root;
    while (curr != nullptr) {
        if (curr->course.courseId == courseId) return curr->course;
        curr = (courseId < curr->course.courseId) ? curr->left : curr->right;
    }
    return Course();  // Return an empty course if not found
}

// FILE PARSING + LOAD
void parseFile(const string& fileName, BinarySearchTree& bst) {
    ifstream inputFile(fileName);
    if (!inputFile.is_open()) {
        cout << "ERROR: File could not be opened. Please try again." << endl;
        return;
    }

    string line;
    while (getline(inputFile, line)) {
        Course course;
        stringstream inputString(line);
        getline(inputString, course.courseId, ',');
        getline(inputString, course.title, ',');

        if (course.courseId.empty() || course.title.empty()) {
            cout << line << " improper format, not added to data structure." << endl;
            continue;
        }

        string prereq;
        while (getline(inputString, prereq, ',')) {
            course.prereq.push_back(prereq);
        }
        bst.Insert(course);
    }
}

// PRINT COURSE INFORMATION
void displayCourse(const Course& course) {
    cout << course.courseId << ", " << course.title << endl;
    cout << "Prerequisites: ";
    if (course.prereq.empty()) {
        cout << "No prerequisites";
    }
    else {
        for (const auto& prereq : course.prereq) {
            cout << prereq << " ";
        }
    }
    cout << endl << endl;
}

// DISPLAY MENU + USER INPUT
void displayMenu(int argc, char* argv[], BinarySearchTree& bst) {
    string csvPath = (argc == 2) ? argv[1] : "CS 300 ABCU_Advising_Program_Input.csv";
    clock_t ticks;

    cout << "Welcome to the course planner." << endl;
    int choice = 0;

    while (choice != 9) {
        cout << "Menu:\n"
            << "  1. Load Data Structure.\n"
            << "  2. Print Course List.\n"
            << "  3. Print Course.\n"
            << "  9. Exit.\n"
            << "What would you like to do? ";

        try {
            cin >> choice;
            if ((choice < 1 || choice > 3) && choice != 9) {
                cout << choice << " is not a valid option." << endl;
                continue;
            }

            string courseId;
            switch (choice) {
            case 1:
                ticks = clock();
                parseFile(csvPath, bst);
                cout << bst.size << " courses read" << endl;
                cout << "time: " << (clock() - ticks) * 1.0 / CLOCKS_PER_SEC << " seconds" << endl;
                break;
            case 2:
                cout << "Here is a sample schedule: " << endl << endl;
                bst.InOrder();
                break;
            case 3:
                cout << "Enter course ID: ";
                cin >> courseId;
                for (char& c : courseId) c = toupper(c);
                displayCourse(bst.Search(courseId));
                break;
            }
        }
        catch (const ios_base::failure& e) {
            cout << "Invalid input. Please enter a number 1-3 or 9." << endl;
            cin.clear();
            cin.ignore(1234, '\n');
        }
    }
    cout << "Thank you for using the course planner!" << endl;
}

int main(int argc, char* argv[]) {
    BinarySearchTree bst;
    displayMenu(argc, argv, bst);
    return 0;
}

